﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bobbing : MonoBehaviour
{

    private float timer = 0.0f;
    float bobbingSpeed = 0f;
    float bobbingAmount = 0f;
    public decimal Breathing;
    void Update()
    {
        if (!(Input.GetKey(KeyCode.LeftShift) && (Input.GetKey(KeyCode.W))))
        {
            bobbingSpeed += 0.0001f;
            bobbingAmount += 0.0001f;
            if (bobbingSpeed >= 0.05)
            {
                bobbingSpeed = 0.06f;
                bobbingAmount = 0.06f;
            }
        }
            if (!(Input.GetKey(KeyCode.LeftShift) && !(Input.GetKey(KeyCode.W))))
            {
                bobbingSpeed += 0f;
                bobbingAmount += 0f;
            }
            if ((Input.GetKey(KeyCode.LeftShift)))
            {
                bobbingSpeed += 0.0005f;
                bobbingAmount += 0.0005f;
                if (bobbingSpeed >= 0.15)
                {
                    bobbingSpeed = 0.15f;
                    bobbingAmount = 0.1f;
                }
            }
            float waveslice = 0.0f;
            float horizontal = Input.GetAxis("Horizontal");
            float vertical = Input.GetAxis("Vertical");

            Vector3 cSharpConversion = transform.localPosition;

            if (Mathf.Abs(horizontal) == 0 && Mathf.Abs(vertical) == 0)
            {
                waveslice = 0;
            }
            else
            {
                waveslice = Mathf.Sin(timer);
                timer = timer + bobbingSpeed;
                if (timer > Mathf.PI * 2)
                {
                    timer = timer - (Mathf.PI * 2);
                }
            }
            if (waveslice != 0)
            {
                float translateChange = waveslice * bobbingAmount;
                cSharpConversion.y = translateChange;
                transform.localPosition = cSharpConversion;
            }
            if (!(Input.GetKey(KeyCode.W) && (Input.GetKey(KeyCode.S) && (Input.GetKey(KeyCode.A) && (Input.GetKey(KeyCode.D))))))
            {
                Breathing++;
                if (Breathing >= 200)
                {
                    cSharpConversion.y += .0001f;
                }
                if (Breathing <= 200)
                {
                    cSharpConversion.y -= .0001f;
                }
                if (Breathing == 400)
                {
                    Breathing -= 400;
                }
                transform.localPosition = cSharpConversion;
            }
        }


    }
