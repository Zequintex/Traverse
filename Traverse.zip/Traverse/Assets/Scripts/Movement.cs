﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(CharacterController))]
public class Movement : MonoBehaviour
{
    //This is how often your waypoint's position will update to the player's position
	//Use this if errors: private float timer = 0.5f;

    public float movementSpeed = 2.0f;
    public float mouseSensitivity = 6.0f;
    public float jumpSpeed = 2.0f;
    public GameObject wayPoint;
    float verticalRotation = 0;
    public float upDownRange = 100.0f;

    float verticalVelocity = 0;

    CharacterController characterController;

    // Use this for initialization
    void Start()
    {
        characterController = GetComponent<CharacterController>();
    }
    // Update is called once per frame
    void Update()
    {
        // Rotation
        float rotLeftRight = Input.GetAxis("Mouse X") * mouseSensitivity;
        transform.Rotate(0, rotLeftRight, 0);
        verticalRotation -= Input.GetAxis("Mouse Y") * mouseSensitivity;
        verticalRotation = Mathf.Clamp(verticalRotation, -upDownRange, upDownRange);
        Camera.main.transform.localRotation = Quaternion.Euler(verticalRotation, 0, 0);
        // Movement
        float forwardSpeed = Input.GetAxis("Vertical") * movementSpeed;
        float sideSpeed = Input.GetAxis("Horizontal") * movementSpeed;
        verticalVelocity += Physics.gravity.y * Time.deltaTime;
        if (characterController.isGrounded && Input.GetButton("Jump"))
        {
            verticalVelocity = jumpSpeed;
        }
        Vector3 speed = new Vector3(sideSpeed, verticalVelocity, forwardSpeed);
        speed = transform.rotation * speed;
        characterController.Move(speed * Time.deltaTime);

        if ((Input.GetKey(KeyCode.LeftShift) && (Input.GetKey(KeyCode.W))))
        {
            movementSpeed += .01f;
            if (movementSpeed >= 4.5f)
            {
                movementSpeed = 4.5f;
            }
        }
        if (!(Input.GetKey(KeyCode.W)))
        {
            movementSpeed -= .05f;
            if (movementSpeed <= 2)
            {
                movementSpeed = 2;
            }
        }
            if (!(Input.GetKey(KeyCode.LeftShift)))
                {
                movementSpeed -= .05f;
                if (movementSpeed <= 2)
                {
                    movementSpeed = 2;
                }
            }
        }
        }